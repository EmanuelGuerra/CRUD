<?php 
	$conexion = mysqli_connect('localhost', 'root', 'root');
	mysqli_select_db($conexion,"bd_crud");
?>